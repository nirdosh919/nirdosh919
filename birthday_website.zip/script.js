function playMusic() {
  const music = document.getElementById('birthdaySong');
  music.play();
}
